package exception;

public class OverDraftLimitExcededException extends RuntimeException {
	public OverDraftLimitExcededException(String message)
	{
		super();
	}
}
