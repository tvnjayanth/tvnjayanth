package util;

import java.util.Properties;

public class DBPropertyUtil {
	
	public static String getConnectionString() {
		
        Properties properties = new Properties();
        properties.setProperty("db.url", "jdbc:mysql://localhost:3306/artgallery");
        properties.setProperty("db.user", "root");
        properties.setProperty("db.password", "root");
        String url = properties.getProperty("db.url", "");
        String user = properties.getProperty("db.user", "");
        String password = properties.getProperty("db.password", "");
        return url +"?useSSL=false&user=" + user + "&password=" + password;
    }

}

