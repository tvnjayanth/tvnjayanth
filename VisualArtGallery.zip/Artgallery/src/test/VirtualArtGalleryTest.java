package test;
import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dao.IVirtualArtGalleryService;
import dao.IVirtualArtGalleryServiceImpl;
import entity.Artwork;
public class VirtualArtGalleryTest{
	private IVirtualArtGalleryService virtualartgalleryservice;
	
	@Before
	public void setup() {
	virtualartgalleryservice = new IVirtualArtGalleryServiceImpl();
    }
    
    @After
    public void teardown() {
    	virtualartgalleryservice=null;
    }
    //@Test
    //public void testAddArtwork() {
    //	Artwork artwork = new Artwork(10,"raju","kitchen",
    //			Date.valueOf("2023-01-02),"
    //					+ "paintings","nine");
    //	boolean result= virtualartgalleryservice.addArtwork(artwork);
    //	assertTrue("Artwork creation success",result);
   // }
   // @Test
    //public void testRemoveArtwork() {
    	//int artwork = 5;
    	//boolean result= virtualartgalleryservice.RemoveArtwork(ArtworkID);
    	//assertTrue("Artwork removed successfully",result);
    }
    
