package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import entity.Artwork;
import exception.ArtworkNotFoundException;
import util.DBConnUtil;
import util.DBPropertyUtil;

public class IVirtualArtGalleryServiceImpl implements IVirtualArtGalleryService {
    private Connection connection;

    // Constructor to initialize the connection using DBConnection class
    public IVirtualArtGalleryServiceImpl() {
        this.connection = DBConnUtil.getConnection(DBPropertyUtil.getConnectionString());
    }
    
    @Override
    public boolean addArtwork(Artwork artwork) {
        try {
            String query = "INSERT INTO Artwork (title, descriptions, creationDate, mediums, imageURL) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            
            preparedStatement.setString(1, artwork.getTitle());
            preparedStatement.setString(2, artwork.getDescriptions());
            preparedStatement.setDate(3, artwork.getCreationDate());
            preparedStatement.setString(4, artwork.getMediums());
            preparedStatement.setString(5, artwork.getImageURL());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    
    @Override
    public boolean updateArtwork(Artwork artwork) {
    	
    	try {
        	if(true) {
        		throw new ArtworkNotFoundException("ArtworkNotFoundException");
        	}
            String query = "UPDATE Artwork SET title = ?, descriptions = ?, creationDate = ?, mediums = ?, imageURL = ? WHERE artworkID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, artwork.getTitle());
            preparedStatement.setString(2, artwork.getDescriptions());
            preparedStatement.setDate(3, artwork.getCreationDate());
            preparedStatement.setString(4, artwork.getMediums());
            preparedStatement.setString(5, artwork.getImageURL());
            preparedStatement.setInt(6, artwork.getArtworkID());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (ArtworkNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
        
    }
    
    
    @Override
    public boolean removeArtwork(int artworkID) {
        try {
        	if(true) {
        		throw new ArtworkNotFoundException("ArtworkNotFoundException");
        	}
            // Remove entries from the user_favorite_artwork table first
            String deleteFromFavoritesQuery = "DELETE FROM User_Favorite_Artwork WHERE ArtworkID = ?";
            PreparedStatement favoritesStatement = connection.prepareStatement(deleteFromFavoritesQuery);
            favoritesStatement.setInt(1, artworkID);
            favoritesStatement.executeUpdate();

            // Remove entries from the artwork_gallery table
            String deleteFromGalleryQuery = "DELETE FROM Artwork_Gallery WHERE ArtworkID = ?";
            PreparedStatement galleryStatement = connection.prepareStatement(deleteFromGalleryQuery);
            galleryStatement.setInt(1, artworkID);
            galleryStatement.executeUpdate();

            // Now, you can delete the artwork
            String deleteArtworkQuery = "DELETE FROM Artwork WHERE ArtworkID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteArtworkQuery);
            preparedStatement.setInt(1, artworkID);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (ArtworkNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
    }
    
    
    @Override
    public Artwork getArtworkById(int artworkID) {
        try {
        	if(artworkID<=0) {
        		throw new ArtworkNotFoundException("ArtworkNotFoundException");
        	}
            String query = "SELECT * FROM Artwork WHERE artworkID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, artworkID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
            	if (resultSet.next()) {
            		System.out.println("Title: " + resultSet.getString("Title"));
            		System.out.println("Description: " + resultSet.getString("Descriptions"));
            		System.out.println("Creation Date: " + resultSet.getDate("CreationDate"));
            		System.out.println("Medium: " + resultSet.getString("Mediums"));
            		System.out.println("Image URL: " + resultSet.getString("ImageURL"));
            	} else {
            		return null;
            	}
            }
        } catch (SQLException e) {
        	e.printStackTrace();
        	return null;
        } catch (ArtworkNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }


    
    @Override
    public List<Integer> getUserFavoriteArtworks(int userID) {
        List<Integer> favoriteArtworkIDs = new ArrayList<>();

        try {
        	if(favoriteArtworkIDs.isEmpty()) {
        		throw new ArtworkNotFoundException("ArtworkNotFoundException");
        	}
            String query = "SELECT ArtworkID FROM User_Favorite_Artwork WHERE UserID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userID);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int artworkID = resultSet.getInt("ArtworkID");
                favoriteArtworkIDs.add(artworkID);
            }

        } catch (SQLException e) {
            // Log or handle the exception appropriately
            e.printStackTrace();
        } catch (ArtworkNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        return favoriteArtworkIDs;
    }
    
    
    @Override
    public List<Artwork> searchArtworks(String keyword) throws ArtworkNotFoundException {
        List<Artwork> artworks = new ArrayList<>();
        String sql = "SELECT * FROM Artwork WHERE LOWER(Title) LIKE LOWER(?) OR LOWER(Descriptions) LIKE LOWER(?)";
        System.out.println("SQL Query: " + sql);
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            String searchPattern = "%" + keyword + "%";
            preparedStatement.setString(1, searchPattern);
            preparedStatement.setString(2, searchPattern);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    artworks.add(mapResultSetToArtwork(resultSet));
                }
            } catch (SQLException e) {
                // Handle or log the exception if needed
                e.printStackTrace();
            }
        } catch (SQLException e) {
            // Handle or log the exception if needed
            e.printStackTrace();
        }

        if (artworks.isEmpty()) {
            // Throw ArtworkNotFoundException if no artworks are found
            throw new ArtworkNotFoundException("No artworks found for the given keyword.");
        }

        return artworks;
    }

    
    
    
    @Override
    public boolean addArtworkToFavorite(int userId, int artworkId) {
        try {
            // Check if the artwork with the given ID exists
            if (artworkExists1(artworkId)) {
                String sql = "INSERT INTO User_Favorite_Artwork (UserID, ArtworkID) VALUES (?, ?)";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setInt(1, userId);
                    preparedStatement.setInt(2, artworkId);

                    int rowsAffected = preparedStatement.executeUpdate();
                    return rowsAffected > 0;
                }
            } else {
                System.out.println("Artwork with ID " + artworkId + " does not exist.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    private boolean artworkExists1(int artworkId) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM Artwork WHERE ArtworkID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, artworkId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt("count") > 0;
            }
        }
    }

   
    private boolean artworkExists(int artworkId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
    public boolean removeArtworkFromFavorite(int userId, int artworkId) {
        String sql = "DELETE FROM User_Favorite_Artwork WHERE UserID=? AND ArtworkID=?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, artworkId);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to map ResultSet to Artwork object
    private Artwork mapResultSetToArtwork(ResultSet resultSet) throws SQLException {
        return new Artwork(
                resultSet.getInt("ArtworkID"),
                resultSet.getString("Title"),
                resultSet.getString("Descriptions"),
                resultSet.getDate("CreationDate"),
                resultSet.getString("Mediums"),
                resultSet.getString("ImageURL")
        );
    }

    
}


