package dao;
import java.util.List;
import entity.Artwork;
import exception.ArtworkNotFoundException;
public interface IVirtualArtGalleryService {

	boolean addArtwork(Artwork artwork);

	boolean updateArtwork(Artwork artwork);

	boolean removeArtwork(int artworkID);

	Artwork getArtworkById(int artworkID);

	List<Integer> getUserFavoriteArtworks(int userID);

	List<Artwork> searchArtworks(String keyword) throws ArtworkNotFoundException;

	boolean addArtworkToFavorite(int userId, int artworkId);

	boolean removeArtworkFromFavorite(int userId, int artworkId);

}
