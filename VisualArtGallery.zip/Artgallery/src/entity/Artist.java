package entity;
import java.sql.Date;
import org.w3c.dom.Text;
public class Artist {
	private int artistID;
	private String artistName;
	private Text biography;
	private Date birthDate;
	private String nationality;
	private Text website;
	private String contactInformation;
	public Artist(int artistID, String artistName, Text biography, Date birthDate, String nationality, Text website,
			String contactInformation) {
		
		this.artistID = artistID;
		this.artistName = artistName;
		this.biography = biography;
		this.birthDate = birthDate;
		this.nationality = nationality;
		this.website = website;
		this.contactInformation = contactInformation;
	}
	public Artist() {
		super();
	}
	public int getArtistID() {
		return artistID;
	}
	public void setArtistID(int artistID) {
		this.artistID = artistID;
	}
	public String getArtistName() {
		return artistName;
	}
	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}
	public Text getBiography() {
		return biography;
	}
	public void setBiography(Text biography) {
		this.biography = biography;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public Text getWebsite() {
		return website;
	}
	public void setWebsite(Text website) {
		this.website = website;
	}
	public String getContactInformation() {
		return contactInformation;
	}
	public void setContactInformation(String contactInformation) {
		this.contactInformation = contactInformation;
	}
	
	public String toString() {
		return "Artist [ArtistID=" + artistID + ", Name=" + artistName + ", Biography=" + biography + ", BirthDate="+ birthDate + ", Nationality=" + nationality + ", Website=" + website + ", contactInfo=" + contactInformation + "]";
	}

}



