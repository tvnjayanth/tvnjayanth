package entity;
public class Gallery {
    private int galleryID;
    private String galleryName;
    private String descriptions;
    private String location;
    private int curator; 
    private String openingHours;
	public Gallery(int galleryID, String galleryName, String descriptions, String location, int curator,
			String openingHours) {
		
		this.galleryID = galleryID;
		this.galleryName = galleryName;
		this.descriptions = descriptions;
		this.location = location;
		this.curator = curator;
		this.openingHours = openingHours;
	}
	public Gallery() {
		super();
	}
	public int getGalleryID() {
		return galleryID;
	}
	public void setGalleryID(int galleryID) {
		this.galleryID = galleryID;
	}
	public String getGalleryName() {
		return galleryName;
	}
	public void setGalleryName(String galleryName) {
		this.galleryName = galleryName;
	}
	public String getDescriptions() {
		return descriptions;
	}
	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCurator() {
		return curator;
	}
	public void setCurator(int curator) {
		this.curator = curator;
	}
	public String getOpeningHours() {
		return openingHours;
	}
	public void setOpeningHours(String openingHours) {
		this.openingHours = openingHours;
	}
	public String toString() {
		return "Gallery [galleryID=" + galleryID + ", name=" + galleryName + ", description=" + descriptions + ", location="
				+ location + ", curator=" + curator + ", openingHours=" + openingHours + "]";
}

}

