package entity;
import java.sql.Date;

public class Artwork {
	private int artworkID;
	private String title;
	private String descriptions;
	private Date creationDate;
	private String mediums;
	private String imageURL;
	public Artwork(int artworkID, String title, String descriptions, Date creationDate, String mediums,
			String imageURL) {
		
		this.artworkID = artworkID;
		this.title = title;
		this.descriptions = descriptions;
		this.creationDate = creationDate;
		this.mediums = mediums;
		this.imageURL = imageURL;
	}
	public Artwork() {
		super();
	}
	public int getArtworkID() {
		return artworkID;
	}
	public void setArtworkID(int artworkID) {
		this.artworkID = artworkID;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescriptions() {
		return descriptions;
	}
	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public String getMediums() {
		return mediums;
	}
	public void setMediums(String mediums) {
		this.mediums = mediums;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public String toString() {
		return "Artwork [ArtworkID=" + artworkID + ", Title=" + title + ", Description=" + descriptions + ", CreationDate=" + creationDate + ", Medium=" + mediums + ", ImageURL=" + imageURL + "]";
	}
}

