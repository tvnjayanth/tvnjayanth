package exception;

@SuppressWarnings("serial")
public class ArtworkNotFoundException extends Exception {
    public ArtworkNotFoundException(String message) {
        super(message);
    }

	public ArtworkNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}

