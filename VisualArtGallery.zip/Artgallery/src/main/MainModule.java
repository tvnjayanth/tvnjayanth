package main;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import dao.IVirtualArtGalleryService;
import dao.IVirtualArtGalleryServiceImpl;
import entity.*;
import exception.ArtworkNotFoundException;

public class MainModule {
	 private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    static IVirtualArtGalleryService ivirtualartgalleryService = new IVirtualArtGalleryServiceImpl();

	public static void main(String[] args) throws ArtworkNotFoundException {
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("\n******** Main Menu ********");
            System.out.println("1. Add the Artwork");
            System.out.println("2. update artwork");
            System.out.println("3. remove artwork");
            System.out.println("4. get artwork by ID");
            System.out.println("5. search artwork");
            System.out.println("6. add artwork to favorite");
            System.out.println("7. remove artwork from favorite");
            System.out.println("8. get user favorite artworks");
            System.out.println("9. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
            case 1:
            	Artwork newArtwork = new Artwork();
            	
            	System.out.print("Enter Title: ");
            	scanner.nextLine();
            	newArtwork.setTitle(scanner.nextLine());
           
            	
            	System.out.print("Enter Description: ");
            	newArtwork.setDescriptions(scanner.nextLine());
            	System.out.print("Enter Creation Date (yyyy-MM-dd): ");
            	String creationDateStr = scanner.nextLine();
            	try {
                    java.sql.Date creationDate = java.sql.Date.valueOf(creationDateStr);
                    newArtwork.setCreationDate(creationDate);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid date format. Please use yyyy-MM-dd.");
                    break;
                }
            	System.out.println("Enter Medium: ");
            	 // Consume the newline character
            	newArtwork.setMediums(scanner.nextLine());
            	
            	System.out.print("Enter Image URL: ");
            	newArtwork.setImageURL(scanner.nextLine());
            	
            	boolean addArtwork = ivirtualartgalleryService.addArtwork(newArtwork);
            	if (addArtwork) {
            		System.out.println("Artwork created successfully.");
            		} else {
            			System.out.println("Failed to create incident.");
            			}
            	break;
            case 2:
            	System.out.print("Enter Artwork ID to update: ");
                int updateArtworkId = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                // Check if the artwork with the given ID exists
                Artwork existingArtwork = ivirtualartgalleryService.getArtworkById(updateArtworkId);

                
                    // Artwork exists, proceed with the update
                    System.out.println("Artwork found. Enter updated details:");

                    Artwork updatedArtwork = new Artwork();
                    updatedArtwork.setArtworkID(updateArtworkId);

                    System.out.print("Enter new Title: ");
                    updatedArtwork.setTitle(scanner.nextLine());

                    System.out.print("Enter new Description: ");
                    updatedArtwork.setDescriptions(scanner.nextLine());

                    System.out.print("Enter new Creation Date (yyyy-MM-dd): ");
                    String updatedCreationDateStr = scanner.next();
                    try {
                        java.sql.Date updateDate = java.sql.Date.valueOf(updatedCreationDateStr);
                       updatedArtwork.setCreationDate(updateDate);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid date format. Please use yyyy-MM-dd.");
                        break;
                    }
                    
                    System.out.println("Enter new Medium: ");
                    scanner.nextLine(); // Consume the newline character
                    updatedArtwork.setMediums(scanner.nextLine());

                    System.out.print("Enter new Image URL: ");
                    updatedArtwork.setImageURL(scanner.nextLine());

                    boolean updateResult = ivirtualartgalleryService.updateArtwork(updatedArtwork);

                    if (updateResult) {
                        System.out.println("Artwork updated successfully.");
                    } else {
                        System.out.println("Failed to update artwork.");
                    }
                 
                
                break;
            case 3:
            	System.out.print("Enter Artwork ID to remove: ");
                int removeArtworkId = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                // Check if the artwork with the given ID exists
                Artwork existingArtwork1 = ivirtualartgalleryService.getArtworkById(removeArtworkId);

                
                    // Artwork exists, proceed with the removal
                    boolean removeResult = ivirtualartgalleryService.removeArtwork(removeArtworkId);

                    if (removeResult) {
                        System.out.println("Artwork removed successfully.");
                    } else {
                        System.out.println("Failed to remove artwork.");
                    }
                
                break;
            case 4:
            	System.out.print("Enter Artwork ID to retrieve details: ");
                int artworkIdToRetrieve = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                // Get artwork details by ID
                Artwork retrievedArtwork = ivirtualartgalleryService.getArtworkById(artworkIdToRetrieve);

                if (retrievedArtwork != null) {
                    // Artwork details found, display them
                    System.out.println("Artwork Details:");
                    System.out.println("Artwork ID: " + retrievedArtwork.getArtworkID());
                    System.out.println("Title: " + retrievedArtwork.getTitle());
                    System.out.println("Description: " + retrievedArtwork.getDescriptions());
                    System.out.println("Creation Date: " + retrievedArtwork.getCreationDate());
                    System.out.println("Medium: " + retrievedArtwork.getMediums());
                    System.out.println("Image URL: " + retrievedArtwork.getImageURL());
                } else {
                    System.out.println("Artwork not found with ID: " + artworkIdToRetrieve);
                }
                break;
            case 5:
            	System.out.print("Enter search keyword: ");
                String searchKeyword = scanner.nextLine();
                scanner.nextLine();

                // Search artworks based on the provided keyword
                List<Artwork> searchedArtworks = ivirtualartgalleryService.searchArtworks(searchKeyword);

                if (!searchedArtworks.isEmpty()) {
                    // Display search results
                    System.out.println("Search Results:" + searchKeyword);
                    for (Artwork artwork : searchedArtworks) {
                        System.out.println("Artwork ID: " + artwork.getArtworkID());
                        System.out.println("Title: " + artwork.getTitle());
                        System.out.println("Description: " + artwork.getDescriptions());
                        System.out.println("Creation Date: " + artwork.getCreationDate());
                        System.out.println("Medium: " + artwork.getMediums());
                        System.out.println("Image URL: " + artwork.getImageURL());
                        System.out.println("------------------------");
                    }
                } else {
                    System.out.println("No artworks found for the keyword: " + searchKeyword);
                }
                break;
            case 6:
            	System.out.print("Enter User ID: ");
                int userIdToAddFavorite = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                System.out.print("Enter Artwork ID to add to favorites: ");
                int artworkIdToAddFavorite = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                // Add artwork to user's favorite list
                boolean addToFavoriteResult = ivirtualartgalleryService.addArtworkToFavorite(userIdToAddFavorite, artworkIdToAddFavorite);

                if (addToFavoriteResult) {
                    System.out.println("Artwork added to favorites successfully.");
                } else {
                    System.out.println("Failed to add artwork to favorites.");
                }
                break;
            case 7:
            	 System.out.print("Enter User ID: ");
            	    int userIdToRemoveFavorite = scanner.nextInt();
            	    scanner.nextLine(); // Consume the newline character

            	    System.out.print("Enter Artwork ID to remove from favorites: ");
            	    int artworkIdToRemoveFavorite = scanner.nextInt();
            	    scanner.nextLine(); // Consume the newline character

            	    // Remove artwork from user's favorite list
            	    boolean removeFromFavoriteResult = ivirtualartgalleryService.removeArtworkFromFavorite(userIdToRemoveFavorite, artworkIdToRemoveFavorite);

            	    if (removeFromFavoriteResult) {
            	        System.out.println("Artwork removed from favorites successfully.");
            	    } else {
            	        System.out.println("Failed to remove artwork from favorites.");
            	    }
                break;
            case 8:
            	System.out.print("Enter User ID to retrieve favorite artworks: ");
                int userIdToRetrieveFavorites = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                // Get user's favorite artworks
                List<Integer> favoriteArtworkIds = ivirtualartgalleryService.getUserFavoriteArtworks(userIdToRetrieveFavorites);

                if (!favoriteArtworkIds.isEmpty()) {
                    // Favorite artworks found, display them
                    System.out.println("Favorite Artworks for User ID " + userIdToRetrieveFavorites + ":");
                    for (int artworkID : favoriteArtworkIds) {
                        Artwork favoriteArtwork = ivirtualartgalleryService.getArtworkById(artworkID);
                        if (favoriteArtwork != null) {
                            System.out.println("Artwork ID: " + favoriteArtwork.getArtworkID());
                            System.out.println("Title: " + favoriteArtwork.getTitle());
                            System.out.println("Description: " + favoriteArtwork.getDescriptions());
                            System.out.println("Creation Date: " + favoriteArtwork.getCreationDate());
                            System.out.println("Medium: " + favoriteArtwork.getMediums());
                            System.out.println("Image URL: " + favoriteArtwork.getImageURL());
                            System.out.println("------------------------");
                        }
                    }
                } else {
                    System.out.println("No favorite artworks found for User ID: " + userIdToRetrieveFavorites);
                }
                break;
            case 9:
                System.out.println("Exiting the program. Goodbye!");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please enter a valid option.");
            	
            }
		}
		}
}